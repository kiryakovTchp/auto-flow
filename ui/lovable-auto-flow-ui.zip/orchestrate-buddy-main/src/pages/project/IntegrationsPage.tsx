import { useState } from 'react';
import { Link, ExternalLink, CheckCircle, XCircle, AlertCircle, Settings, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { EmptyState } from '@/components/EmptyState';

export function IntegrationsPage() {
  const { role } = useAuth();
  const { toast } = useToast();
  const canManage = role === 'admin' || role === 'instance_admin';

  const [asanaConnected, setAsanaConnected] = useState(true);
  const [githubConnected, setGithubConnected] = useState(true);
  const [opencodeConnected, setOpencodeConnected] = useState(false);

  const handleConnect = (integration: string) => {
    toast({
      title: `Connecting to ${integration}`,
      description: 'Redirecting to authorization...',
    });
  };

  const handleDisconnect = (integration: string) => {
    toast({
      title: `Disconnected from ${integration}`,
      description: 'Integration has been removed.',
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Integrations</h1>
        <p className="text-muted-foreground">
          Connect and manage external services
        </p>
      </div>

      <Tabs defaultValue="asana">
        <TabsList className="border-2 border-border bg-transparent p-1 h-auto flex-wrap">
          <TabsTrigger 
            value="asana"
            className="border-2 border-transparent data-[state=active]:border-border data-[state=active]:bg-accent"
          >
            Asana
            {asanaConnected ? (
              <CheckCircle className="h-3 w-3 ml-2 text-chart-2" />
            ) : (
              <XCircle className="h-3 w-3 ml-2 text-muted-foreground" />
            )}
          </TabsTrigger>
          <TabsTrigger 
            value="github"
            className="border-2 border-transparent data-[state=active]:border-border data-[state=active]:bg-accent"
          >
            GitHub
            {githubConnected ? (
              <CheckCircle className="h-3 w-3 ml-2 text-chart-2" />
            ) : (
              <XCircle className="h-3 w-3 ml-2 text-muted-foreground" />
            )}
          </TabsTrigger>
          <TabsTrigger 
            value="opencode"
            className="border-2 border-transparent data-[state=active]:border-border data-[state=active]:bg-accent"
          >
            OpenCode
            {opencodeConnected ? (
              <CheckCircle className="h-3 w-3 ml-2 text-chart-2" />
            ) : (
              <XCircle className="h-3 w-3 ml-2 text-muted-foreground" />
            )}
          </TabsTrigger>
        </TabsList>

        {/* Asana */}
        <TabsContent value="asana" className="mt-6 space-y-4">
          <Card className="border-2 border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Asana
                    {asanaConnected && (
                      <span className="text-xs bg-chart-2/20 text-chart-2 px-2 py-0.5 border border-chart-2/30">
                        Connected
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription>Sync tasks and track progress</CardDescription>
                </div>
                {canManage && (
                  asanaConnected ? (
                    <Button 
                      variant="outline" 
                      className="border-2"
                      onClick={() => handleDisconnect('Asana')}
                    >
                      Disconnect
                    </Button>
                  ) : (
                    <Button onClick={() => handleConnect('Asana')} className="shadow-xs">
                      Connect
                    </Button>
                  )
                )}
              </div>
            </CardHeader>
            {asanaConnected && (
              <CardContent className="space-y-4">
                <div className="p-4 border-2 border-border bg-muted/50">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Workspace</p>
                      <p className="font-medium">Engineering Team</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Project</p>
                      <p className="font-medium">Platform Development</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Last Sync</p>
                      <p className="font-medium">5 minutes ago</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Tasks Synced</p>
                      <p className="font-medium">156</p>
                    </div>
                  </div>
                </div>
                {canManage && (
                  <Button variant="outline" className="border-2">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Sync Now
                  </Button>
                )}
              </CardContent>
            )}
          </Card>
        </TabsContent>

        {/* GitHub */}
        <TabsContent value="github" className="mt-6 space-y-4">
          <Card className="border-2 border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    GitHub
                    {githubConnected && (
                      <span className="text-xs bg-chart-2/20 text-chart-2 px-2 py-0.5 border border-chart-2/30">
                        Connected
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription>Create issues and track pull requests</CardDescription>
                </div>
                {canManage && (
                  githubConnected ? (
                    <Button 
                      variant="outline" 
                      className="border-2"
                      onClick={() => handleDisconnect('GitHub')}
                    >
                      Disconnect
                    </Button>
                  ) : (
                    <Button onClick={() => handleConnect('GitHub')} className="shadow-xs">
                      Connect
                    </Button>
                  )
                )}
              </div>
            </CardHeader>
            {githubConnected && (
              <CardContent className="space-y-4">
                <div className="p-4 border-2 border-border bg-muted/50">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Organization</p>
                      <p className="font-medium">acme-corp</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Repositories</p>
                      <p className="font-medium">3 connected</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Open Issues</p>
                      <p className="font-medium">12</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Open PRs</p>
                      <p className="font-medium">8</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        </TabsContent>

        {/* OpenCode */}
        <TabsContent value="opencode" className="mt-6 space-y-4">
          <Card className="border-2 border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    OpenCode
                    {opencodeConnected && (
                      <span className="text-xs bg-chart-2/20 text-chart-2 px-2 py-0.5 border border-chart-2/30">
                        Connected
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription>AI-powered code generation and automation</CardDescription>
                </div>
                {canManage && (
                  opencodeConnected ? (
                    <Button 
                      variant="outline" 
                      className="border-2"
                      onClick={() => handleDisconnect('OpenCode')}
                    >
                      Disconnect
                    </Button>
                  ) : (
                    <Button onClick={() => handleConnect('OpenCode')} className="shadow-xs">
                      Connect
                    </Button>
                  )
                )}
              </div>
            </CardHeader>
            {!opencodeConnected && (
              <CardContent>
                <EmptyState
                  icon={Settings}
                  title="OpenCode not connected"
                  description="Connect OpenCode to enable AI-powered code generation and automated task execution."
                  action={canManage ? {
                    label: 'Connect OpenCode',
                    onClick: () => handleConnect('OpenCode'),
                  } : undefined}
                />
              </CardContent>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
