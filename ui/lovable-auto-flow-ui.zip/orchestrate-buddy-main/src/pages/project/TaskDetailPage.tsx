import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  ExternalLink, 
  Play, 
  RefreshCw, 
  GitBranch,
  MessageSquare,
  Clock,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { StatusChip } from '@/components/StatusChip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { Textarea } from '@/components/ui/textarea';

// Mock data
const mockTask = {
  id: '1',
  title: 'Implement user authentication flow',
  status: 'PR_CREATED' as const,
  description: 'Add complete user authentication including login, signup, password reset, and session management. Use JWT tokens for API authentication.',
  projectId: '1',
  createdAt: '2024-01-20T10:00:00Z',
  updatedAt: '2024-01-21T15:30:00Z',
  asanaTaskId: 'asana-123',
  githubIssueUrl: 'https://github.com/org/repo/issues/42',
  githubPrUrl: 'https://github.com/org/repo/pull/43',
};

const mockSpec = {
  id: '1',
  content: `## Implementation Plan

### 1. Authentication Service
- Create AuthService class with JWT token management
- Implement login/logout/signup methods
- Add password reset flow with email verification

### 2. API Endpoints
- POST /api/auth/login
- POST /api/auth/signup  
- POST /api/auth/logout
- POST /api/auth/reset-password

### 3. Frontend Components
- LoginForm component with validation
- SignupForm component
- PasswordResetForm component
- AuthContext provider

### 4. Security Considerations
- Use bcrypt for password hashing
- Implement rate limiting on auth endpoints
- Add CSRF protection`,
  createdAt: '2024-01-20T12:00:00Z',
};

const mockEvents = [
  { id: '1', type: 'created', message: 'Task received from Asana', time: '2024-01-20T10:00:00Z' },
  { id: '2', type: 'spec', message: 'Task spec generated', time: '2024-01-20T12:00:00Z' },
  { id: '3', type: 'issue', message: 'GitHub issue #42 created', time: '2024-01-20T14:00:00Z' },
  { id: '4', type: 'run', message: 'OpenCode run started', time: '2024-01-21T09:00:00Z' },
  { id: '5', type: 'pr', message: 'PR #43 created', time: '2024-01-21T15:30:00Z' },
];

export function TaskDetailPage() {
  const { taskId } = useParams();
  const { role } = useAuth();

  const canEdit = role === 'editor' || role === 'admin' || role === 'instance_admin';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Link to="/project/tasks">
          <Button variant="ghost" size="icon" className="shrink-0">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-2">
            <span className="font-mono text-sm text-muted-foreground">#{taskId}</span>
            <StatusChip status={mockTask.status} />
          </div>
          <h1 className="text-2xl font-bold">{mockTask.title}</h1>
          <p className="text-muted-foreground mt-2">{mockTask.description}</p>
        </div>
      </div>

      {/* Actions */}
      {canEdit && (
        <Card className="border-2 border-border">
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-2">
              <Button className="shadow-xs">
                <Play className="h-4 w-4 mr-2" />
                Run OpenCode
              </Button>
              <Button variant="outline" className="border-2">
                <RefreshCw className="h-4 w-4 mr-2" />
                Resync
              </Button>
              <Button variant="outline" className="border-2">
                <GitBranch className="h-4 w-4 mr-2" />
                Link PR
              </Button>
              <Button variant="outline" className="border-2">
                <MessageSquare className="h-4 w-4 mr-2" />
                Add Asana Note
              </Button>
              {mockTask.githubPrUrl && (
                <Button 
                  variant="outline" 
                  className="border-2"
                  onClick={() => window.open(mockTask.githubPrUrl, '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View PR
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs defaultValue="spec">
        <TabsList className="border-2 border-border bg-transparent p-1 h-auto">
          <TabsTrigger 
            value="spec" 
            className="border-2 border-transparent data-[state=active]:border-border data-[state=active]:bg-accent"
          >
            <FileText className="h-4 w-4 mr-2" />
            Spec
          </TabsTrigger>
          <TabsTrigger 
            value="timeline"
            className="border-2 border-transparent data-[state=active]:border-border data-[state=active]:bg-accent"
          >
            <Clock className="h-4 w-4 mr-2" />
            Timeline
          </TabsTrigger>
        </TabsList>

        <TabsContent value="spec" className="mt-4">
          <Card className="border-2 border-border">
            <CardHeader>
              <CardTitle className="text-base font-medium">Task Specification</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <pre className="bg-muted p-4 border-2 border-border text-sm whitespace-pre-wrap font-mono">
                  {mockSpec.content}
                </pre>
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                Generated {new Date(mockSpec.createdAt).toLocaleString()}
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline" className="mt-4">
          <Card className="border-2 border-border">
            <CardHeader>
              <CardTitle className="text-base font-medium">Event Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockEvents.map((event, index) => (
                  <div key={event.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-3 w-3 bg-primary" />
                      {index < mockEvents.length - 1 && (
                        <div className="w-0.5 flex-1 bg-border mt-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="font-medium text-sm">{event.message}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(event.time).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Metadata */}
      <Card className="border-2 border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium">Links & References</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {mockTask.asanaTaskId && (
              <div className="p-3 border-2 border-border">
                <p className="text-xs text-muted-foreground mb-1">Asana Task</p>
                <a href="#" className="text-sm font-medium hover:underline flex items-center gap-1">
                  {mockTask.asanaTaskId}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
            {mockTask.githubIssueUrl && (
              <div className="p-3 border-2 border-border">
                <p className="text-xs text-muted-foreground mb-1">GitHub Issue</p>
                <a 
                  href={mockTask.githubIssueUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm font-medium hover:underline flex items-center gap-1"
                >
                  Issue #42
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
            {mockTask.githubPrUrl && (
              <div className="p-3 border-2 border-border">
                <p className="text-xs text-muted-foreground mb-1">Pull Request</p>
                <a 
                  href={mockTask.githubPrUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm font-medium hover:underline flex items-center gap-1"
                >
                  PR #43
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
