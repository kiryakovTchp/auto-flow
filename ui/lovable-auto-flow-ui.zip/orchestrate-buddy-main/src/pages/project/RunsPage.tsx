import { Play, CheckCircle, XCircle, Clock, ExternalLink, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

const mockRuns = [
  {
    id: '1',
    taskId: '1',
    taskTitle: 'Implement user authentication',
    status: 'completed' as const,
    startedAt: '2024-01-21T14:00:00Z',
    completedAt: '2024-01-21T15:30:00Z',
    duration: '1h 30m',
    logs: [
      '[14:00:00] Starting OpenCode run...',
      '[14:00:05] Analyzing task specification...',
      '[14:05:00] Generating implementation plan...',
      '[14:10:00] Creating auth service...',
      '[14:30:00] Creating login component...',
      '[14:50:00] Creating signup component...',
      '[15:10:00] Running tests...',
      '[15:25:00] All tests passed',
      '[15:30:00] Run completed successfully',
    ],
  },
  {
    id: '2',
    taskId: '2',
    taskTitle: 'Add payment processing',
    status: 'running' as const,
    startedAt: '2024-01-21T16:00:00Z',
    duration: '15m (running)',
    logs: [
      '[16:00:00] Starting OpenCode run...',
      '[16:00:05] Analyzing task specification...',
      '[16:05:00] Generating implementation plan...',
      '[16:10:00] Implementing Stripe integration...',
      '[16:15:00] Processing...',
    ],
  },
  {
    id: '3',
    taskId: '3',
    taskTitle: 'Fix navigation bug',
    status: 'failed' as const,
    startedAt: '2024-01-21T10:00:00Z',
    completedAt: '2024-01-21T10:15:00Z',
    duration: '15m',
    logs: [
      '[10:00:00] Starting OpenCode run...',
      '[10:00:05] Analyzing task specification...',
      '[10:05:00] Generating fix...',
      '[10:10:00] Applying changes...',
      '[10:12:00] Error: Could not find component',
      '[10:15:00] Run failed',
    ],
  },
];

export function RunsPage() {
  const { role } = useAuth();
  const canRetry = role === 'editor' || role === 'admin' || role === 'instance_admin';

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-chart-2" />;
      case 'running':
        return <Clock className="h-4 w-4 text-chart-1 animate-pulse" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-destructive" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-chart-2/20 text-chart-2 border-chart-2/30">Completed</Badge>;
      case 'running':
        return <Badge className="bg-chart-1/20 text-chart-1 border-chart-1/30">Running</Badge>;
      case 'failed':
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30">Failed</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Runs</h1>
        <p className="text-muted-foreground">
          OpenCode execution history
        </p>
      </div>

      <div className="space-y-4">
        {mockRuns.map((run) => (
          <Card key={run.id} className="border-2 border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    {getStatusIcon(run.status)}
                    <Link 
                      to={`/project/tasks/${run.taskId}`}
                      className="font-medium hover:underline"
                    >
                      {run.taskTitle}
                    </Link>
                    {getStatusBadge(run.status)}
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>Started {new Date(run.startedAt).toLocaleString()}</span>
                    <span>Duration: {run.duration}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="border-2">
                        View Logs
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="border-2 border-border max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Run Logs - {run.taskTitle}</DialogTitle>
                      </DialogHeader>
                      <ScrollArea className="h-96 mt-4">
                        <pre className="bg-primary text-primary-foreground p-4 text-sm font-mono">
                          {run.logs.join('\n')}
                        </pre>
                      </ScrollArea>
                    </DialogContent>
                  </Dialog>
                  {canRetry && run.status === 'failed' && (
                    <Button size="sm" className="shadow-xs">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Retry
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
