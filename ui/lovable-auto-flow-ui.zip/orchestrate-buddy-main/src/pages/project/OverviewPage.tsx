import { 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Activity,
  GitPullRequest,
  ListTodo,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useProject } from '@/contexts/ProjectContext';
import { IntegrationBadge } from '@/components/IntegrationBadge';
import { StatusChip } from '@/components/StatusChip';
import { Task, TaskStatus } from '@/types';

// Mock data
const mockTasks: Task[] = [
  { id: '1', title: 'Implement user authentication', status: 'PR_CREATED', projectId: '1', createdAt: '2024-01-20', updatedAt: '2024-01-21' },
  { id: '2', title: 'Add payment processing', status: 'ISSUE_CREATED', projectId: '1', createdAt: '2024-01-19', updatedAt: '2024-01-20' },
  { id: '3', title: 'Fix navigation bug', status: 'WAITING_CI', projectId: '1', createdAt: '2024-01-18', updatedAt: '2024-01-19' },
  { id: '4', title: 'Update dependencies', status: 'DEPLOYED', projectId: '1', createdAt: '2024-01-17', updatedAt: '2024-01-18' },
];

const mockEvents = [
  { id: '1', type: 'sync', message: 'Synced 12 tasks from Asana', time: '5 min ago' },
  { id: '2', type: 'pr', message: 'PR #42 created for "User auth"', time: '1 hour ago' },
  { id: '3', type: 'deploy', message: 'Task "Fix nav bug" deployed', time: '2 hours ago' },
  { id: '4', type: 'run', message: 'OpenCode run completed', time: '3 hours ago' },
];

export function OverviewPage() {
  const { currentProject } = useProject();

  if (!currentProject) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Select a project to view overview</p>
      </div>
    );
  }

  const stats = [
    { label: 'Active Tasks', value: 24, icon: ListTodo, trend: '+3 this week' },
    { label: 'PRs Open', value: 8, icon: GitPullRequest, trend: '2 pending review' },
    { label: 'Success Rate', value: '94%', icon: CheckCircle, trend: 'Last 30 days' },
    { label: 'Avg. Cycle Time', value: '2.4d', icon: Clock, trend: '-0.5d vs last month' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">{currentProject.name}</h1>
          <p className="text-muted-foreground">{currentProject.description}</p>
        </div>
        <Button className="shadow-sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Sync from Asana
        </Button>
      </div>

      {/* Integration Status */}
      <Card className="border-2 border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium">Integration Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <IntegrationBadge type="asana" connected={currentProject.integrations.asana} />
            <IntegrationBadge type="github" connected={currentProject.integrations.github} />
            <IntegrationBadge type="opencode" connected={currentProject.integrations.opencode} />
          </div>
          {(!currentProject.integrations.asana || !currentProject.integrations.github) && (
            <div className="mt-4 p-3 bg-chart-4/10 border-2 border-chart-4/30 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-chart-4 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-sm">Setup incomplete</p>
                <p className="text-sm text-muted-foreground">
                  Connect all integrations to enable full automation.{' '}
                  <Link to="/project/integrations" className="underline hover:text-foreground">
                    Configure integrations →
                  </Link>
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-2 border-border">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.trend}</p>
                </div>
                <div className="h-10 w-10 border-2 border-border bg-accent flex items-center justify-center">
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Tasks */}
        <Card className="border-2 border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-medium">Recent Tasks</CardTitle>
            <Link to="/project/tasks">
              <Button variant="ghost" size="sm">
                View All <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockTasks.map((task) => (
                <Link
                  key={task.id}
                  to={`/project/tasks/${task.id}`}
                  className="flex items-center justify-between p-3 border-2 border-border hover:bg-accent transition-colors"
                >
                  <span className="font-medium text-sm truncate flex-1 mr-4">{task.title}</span>
                  <StatusChip status={task.status} />
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Activity Feed */}
        <Card className="border-2 border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockEvents.map((event) => (
                <div key={event.id} className="flex items-start gap-3">
                  <div className="h-2 w-2 bg-primary mt-2 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{event.message}</p>
                    <p className="text-xs text-muted-foreground">{event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
