import { NavLink as RouterNavLink, useLocation } from 'react-router-dom';
import { 
  Key, 
  GitBranch, 
  Settings2, 
  Map, 
  Database, 
  KeyRound, 
  BookOpen, 
  Link as LinkIcon,
  Plus,
  Trash2,
  Edit
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { EmptyState } from '@/components/EmptyState';
import { useState } from 'react';

const settingsSections = [
  { id: 'secrets', label: 'Secrets', icon: Key },
  { id: 'repos', label: 'Repositories', icon: GitBranch },
  { id: 'asana-fields', label: 'Asana Fields', icon: Settings2 },
  { id: 'status-mapping', label: 'Status Mapping', icon: Map },
  { id: 'repo-mapping', label: 'Repo Mapping', icon: Database },
  { id: 'api-tokens', label: 'API Tokens', icon: KeyRound },
  { id: 'knowledge', label: 'Knowledge', icon: BookOpen },
  { id: 'links', label: 'Contacts & Links', icon: LinkIcon },
];

const mockSecrets = [
  { id: '1', key: 'ASANA_TOKEN', createdAt: '2024-01-15' },
  { id: '2', key: 'GITHUB_TOKEN', createdAt: '2024-01-15' },
  { id: '3', key: 'OPENCODE_API_KEY', createdAt: '2024-01-16' },
];

const mockRepos = [
  { id: '1', name: 'platform-core', fullName: 'acme/platform-core', defaultBranch: 'main' },
  { id: '2', name: 'mobile-app', fullName: 'acme/mobile-app', defaultBranch: 'develop' },
];

const mockTokens = [
  { id: '1', name: 'CI/CD Pipeline', lastUsed: '2024-01-21', createdAt: '2024-01-10' },
  { id: '2', name: 'External Service', lastUsed: '2024-01-20', createdAt: '2024-01-12' },
];

export function SettingsPage() {
  const { role } = useAuth();
  const canManage = role === 'admin' || role === 'instance_admin';
  const [activeSection, setActiveSection] = useState('secrets');

  const renderSection = () => {
    switch (activeSection) {
      case 'secrets':
        return (
          <Card className="border-2 border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Project Secrets</CardTitle>
                <CardDescription>Encrypted environment variables</CardDescription>
              </div>
              {canManage && (
                <Button size="sm" className="shadow-xs">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Secret
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {mockSecrets.map((secret) => (
                  <div key={secret.id} className="flex items-center justify-between p-3 border-2 border-border">
                    <div>
                      <p className="font-mono font-medium">{secret.key}</p>
                      <p className="text-xs text-muted-foreground">Added {secret.createdAt}</p>
                    </div>
                    {canManage && (
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'repos':
        return (
          <Card className="border-2 border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Connected Repositories</CardTitle>
                <CardDescription>GitHub repositories linked to this project</CardDescription>
              </div>
              {canManage && (
                <Button size="sm" className="shadow-xs">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Repository
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {mockRepos.map((repo) => (
                  <div key={repo.id} className="flex items-center justify-between p-3 border-2 border-border">
                    <div className="flex items-center gap-3">
                      <GitBranch className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{repo.fullName}</p>
                        <p className="text-xs text-muted-foreground">Default: {repo.defaultBranch}</p>
                      </div>
                    </div>
                    {canManage && (
                      <Button variant="ghost" size="icon" className="text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'api-tokens':
        return (
          <Card className="border-2 border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>API Tokens</CardTitle>
                <CardDescription>Tokens for external API access</CardDescription>
              </div>
              {canManage && (
                <Button size="sm" className="shadow-xs">
                  <Plus className="h-4 w-4 mr-2" />
                  Generate Token
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {mockTokens.map((token) => (
                  <div key={token.id} className="flex items-center justify-between p-3 border-2 border-border">
                    <div>
                      <p className="font-medium">{token.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Last used: {token.lastUsed} • Created: {token.createdAt}
                      </p>
                    </div>
                    {canManage && (
                      <Button variant="ghost" size="icon" className="text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'knowledge':
        return (
          <Card className="border-2 border-border">
            <CardHeader>
              <CardTitle>Knowledge Base</CardTitle>
              <CardDescription>Context and documentation for AI assistance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="context">Project Context</Label>
                <Textarea
                  id="context"
                  placeholder="Describe your project, coding standards, architecture decisions..."
                  className="border-2 min-h-32"
                  disabled={!canManage}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="guidelines">Coding Guidelines</Label>
                <Textarea
                  id="guidelines"
                  placeholder="TypeScript best practices, naming conventions, etc..."
                  className="border-2 min-h-32"
                  disabled={!canManage}
                />
              </div>
              {canManage && (
                <Button className="shadow-xs">Save Changes</Button>
              )}
            </CardContent>
          </Card>
        );

      case 'links':
        return (
          <Card className="border-2 border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Contacts & Links</CardTitle>
                <CardDescription>Team contacts and useful resources</CardDescription>
              </div>
              {canManage && (
                <Button size="sm" className="shadow-xs">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Link
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <EmptyState
                icon={LinkIcon}
                title="No links added"
                description="Add team contacts, documentation links, and other resources."
                action={canManage ? {
                  label: 'Add Link',
                  onClick: () => {},
                } : undefined}
              />
            </CardContent>
          </Card>
        );

      default:
        return (
          <Card className="border-2 border-border">
            <CardContent className="py-12">
              <EmptyState
                icon={Settings2}
                title="Coming soon"
                description={`The ${activeSection} section is under development.`}
              />
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">
          Configure project settings and integrations
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Settings Navigation */}
        <Card className="border-2 border-border lg:col-span-1 h-fit">
          <CardContent className="p-2">
            <nav className="space-y-1">
              {settingsSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2 text-sm transition-colors text-left ${
                    activeSection === section.id
                      ? 'bg-accent font-medium'
                      : 'hover:bg-muted'
                  }`}
                >
                  <section.icon className="h-4 w-4" />
                  {section.label}
                </button>
              ))}
            </nav>
          </CardContent>
        </Card>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          {renderSection()}
        </div>
      </div>
    </div>
  );
}
