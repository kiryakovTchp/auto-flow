import { useState } from 'react';
import { Plus, Webhook, CheckCircle, XCircle, AlertTriangle, MoreHorizontal, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { EmptyState } from '@/components/EmptyState';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

const mockWebhooks = [
  {
    id: '1',
    name: 'Slack Notifications',
    url: 'https://hooks.slack.com/services/xxx',
    events: ['task.created', 'task.deployed'],
    status: 'active' as const,
    lastTriggered: '2024-01-21T15:30:00Z',
  },
  {
    id: '2',
    name: 'Discord Bot',
    url: 'https://discord.com/api/webhooks/xxx',
    events: ['pr.created', 'pr.merged'],
    status: 'active' as const,
    lastTriggered: '2024-01-21T12:00:00Z',
  },
  {
    id: '3',
    name: 'Monitoring Service',
    url: 'https://monitor.example.com/webhook',
    events: ['task.failed'],
    status: 'error' as const,
    lastTriggered: '2024-01-20T08:00:00Z',
  },
];

const availableEvents = [
  { id: 'task.created', label: 'Task Created' },
  { id: 'task.deployed', label: 'Task Deployed' },
  { id: 'task.failed', label: 'Task Failed' },
  { id: 'pr.created', label: 'PR Created' },
  { id: 'pr.merged', label: 'PR Merged' },
  { id: 'run.started', label: 'Run Started' },
  { id: 'run.completed', label: 'Run Completed' },
];

export function WebhooksPage() {
  const { role } = useAuth();
  const canManage = role === 'admin' || role === 'instance_admin';
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newWebhook, setNewWebhook] = useState({ name: '', url: '', events: [] as string[] });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-4 w-4 text-chart-2" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      default:
        return <XCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const toggleEvent = (eventId: string) => {
    setNewWebhook((prev) => ({
      ...prev,
      events: prev.events.includes(eventId)
        ? prev.events.filter((e) => e !== eventId)
        : [...prev.events, eventId],
    }));
  };

  if (mockWebhooks.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Webhooks</h1>
          <p className="text-muted-foreground">
            Configure outgoing webhooks for events
          </p>
        </div>
        <EmptyState
          icon={Webhook}
          title="No webhooks configured"
          description="Add webhooks to receive notifications when events occur in your project."
          action={canManage ? {
            label: 'Add Webhook',
            onClick: () => setIsCreateOpen(true),
          } : undefined}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Webhooks</h1>
          <p className="text-muted-foreground">
            {mockWebhooks.length} webhooks configured
          </p>
        </div>
        {canManage && (
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="shadow-sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Webhook
              </Button>
            </DialogTrigger>
            <DialogContent className="border-2 border-border">
              <DialogHeader>
                <DialogTitle>Add Webhook</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={newWebhook.name}
                    onChange={(e) => setNewWebhook({ ...newWebhook, name: e.target.value })}
                    placeholder="My Webhook"
                    className="border-2"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="url">Webhook URL</Label>
                  <Input
                    id="url"
                    value={newWebhook.url}
                    onChange={(e) => setNewWebhook({ ...newWebhook, url: e.target.value })}
                    placeholder="https://example.com/webhook"
                    className="border-2"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Events</Label>
                  <div className="grid gap-2">
                    {availableEvents.map((event) => (
                      <div key={event.id} className="flex items-center gap-2">
                        <Checkbox
                          id={event.id}
                          checked={newWebhook.events.includes(event.id)}
                          onCheckedChange={() => toggleEvent(event.id)}
                        />
                        <label htmlFor={event.id} className="text-sm cursor-pointer">
                          {event.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                <Button onClick={() => setIsCreateOpen(false)} className="w-full shadow-sm">
                  Create Webhook
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="space-y-3">
        {mockWebhooks.map((webhook) => (
          <Card key={webhook.id} className="border-2 border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    {getStatusIcon(webhook.status)}
                    <span className="font-medium">{webhook.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {webhook.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground font-mono truncate mb-2">
                    {webhook.url}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {webhook.events.map((event) => (
                      <span
                        key={event}
                        className="text-xs bg-muted px-2 py-0.5 border border-border"
                      >
                        {event}
                      </span>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Last triggered: {new Date(webhook.lastTriggered).toLocaleString()}
                  </p>
                </div>
                {canManage && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="border-2 border-border bg-popover">
                      <DropdownMenuItem>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Test</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
