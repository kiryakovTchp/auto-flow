import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Plus, 
  Filter, 
  ArrowUpDown, 
  ExternalLink,
  MoreHorizontal,
  Play,
  RefreshCw,
  GitBranch
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { StatusChip } from '@/components/StatusChip';
import { Task, TaskStatus } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Mock data
const mockTasks: Task[] = [
  { id: '1', title: 'Implement user authentication flow', status: 'PR_CREATED', projectId: '1', createdAt: '2024-01-20', updatedAt: '2024-01-21', githubPrUrl: 'https://github.com/org/repo/pull/42' },
  { id: '2', title: 'Add payment processing integration', status: 'ISSUE_CREATED', projectId: '1', createdAt: '2024-01-19', updatedAt: '2024-01-20', githubIssueUrl: 'https://github.com/org/repo/issues/43' },
  { id: '3', title: 'Fix navigation bug on mobile', status: 'WAITING_CI', projectId: '1', createdAt: '2024-01-18', updatedAt: '2024-01-19' },
  { id: '4', title: 'Update all npm dependencies', status: 'DEPLOYED', projectId: '1', createdAt: '2024-01-17', updatedAt: '2024-01-18' },
  { id: '5', title: 'Implement dark mode toggle', status: 'TASKSPEC_CREATED', projectId: '1', createdAt: '2024-01-16', updatedAt: '2024-01-16' },
  { id: '6', title: 'Add API rate limiting', status: 'RECEIVED', projectId: '1', createdAt: '2024-01-15', updatedAt: '2024-01-15' },
  { id: '7', title: 'Fix broken image uploads', status: 'FAILED', projectId: '1', createdAt: '2024-01-14', updatedAt: '2024-01-15' },
  { id: '8', title: 'Improve search performance', status: 'BLOCKED', projectId: '1', createdAt: '2024-01-13', updatedAt: '2024-01-14' },
];

const statusFilters: TaskStatus[] = [
  'RECEIVED', 'TASKSPEC_CREATED', 'NEEDS_REPO', 'ISSUE_CREATED', 
  'PR_CREATED', 'WAITING_CI', 'DEPLOYED', 'FAILED', 'BLOCKED'
];

export function TasksPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { role } = useAuth();

  const canEdit = role === 'editor' || role === 'admin' || role === 'instance_admin';

  const filteredTasks = mockTasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Tasks</h1>
          <p className="text-muted-foreground">
            {filteredTasks.length} tasks
          </p>
        </div>
        {canEdit && (
          <Button className="shadow-sm">
            <Plus className="h-4 w-4 mr-2" />
            Create Task
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card className="border-2 border-border">
        <CardContent className="pt-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tasks..."
                className="pl-10 border-2"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48 border-2">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent className="border-2 border-border bg-popover">
                <SelectItem value="all">All Statuses</SelectItem>
                {statusFilters.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status.replace('_', ' ')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-2">
              <ArrowUpDown className="h-4 w-4 mr-2" />
              Sort
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tasks List */}
      <div className="space-y-2">
        {filteredTasks.map((task) => (
          <Link
            key={task.id}
            to={`/project/tasks/${task.id}`}
            className="block"
          >
            <Card className="border-2 border-border hover:shadow-sm transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-mono text-xs text-muted-foreground">#{task.id}</span>
                      <StatusChip status={task.status} />
                    </div>
                    <h3 className="font-medium truncate">{task.title}</h3>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Updated {new Date(task.updatedAt).toLocaleDateString()}</span>
                      {task.githubPrUrl && (
                        <span className="flex items-center gap-1">
                          <GitBranch className="h-3 w-3" />
                          PR #42
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {task.githubPrUrl && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={(e) => {
                          e.preventDefault();
                          window.open(task.githubPrUrl, '_blank');
                        }}
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    )}
                    
                    {canEdit && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.preventDefault()}>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="border-2 border-border bg-popover">
                          <DropdownMenuItem>
                            <Play className="h-4 w-4 mr-2" />
                            Run OpenCode
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Resync
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <GitBranch className="h-4 w-4 mr-2" />
                            Link PR
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {filteredTasks.length === 0 && (
        <div className="text-center py-12 border-2 border-dashed border-border">
          <p className="text-muted-foreground">No tasks match your filters</p>
        </div>
      )}
    </div>
  );
}
