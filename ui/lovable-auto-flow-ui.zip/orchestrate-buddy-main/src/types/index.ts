// Core types for Auto-Flow

export type UserRole = 'viewer' | 'editor' | 'admin' | 'instance_admin';

export type TaskStatus = 
  | 'RECEIVED'
  | 'TASKSPEC_CREATED'
  | 'NEEDS_REPO'
  | 'AUTO_DISABLED'
  | 'CANCELLED'
  | 'BLOCKED'
  | 'ISSUE_CREATED'
  | 'PR_CREATED'
  | 'WAITING_CI'
  | 'DEPLOYED'
  | 'FAILED';

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  integrations: {
    asana: boolean;
    github: boolean;
    opencode: boolean;
  };
  memberCount: number;
}

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  projectId: string;
  asanaTaskId?: string;
  githubIssueUrl?: string;
  githubPrUrl?: string;
  createdAt: string;
  updatedAt: string;
  assignee?: User;
}

export interface TaskSpec {
  id: string;
  taskId: string;
  content: string;
  createdAt: string;
}

export interface TaskEvent {
  id: string;
  taskId: string;
  type: string;
  message: string;
  createdAt: string;
}

export interface Integration {
  id: string;
  type: 'asana' | 'github' | 'opencode';
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
  config?: Record<string, unknown>;
}

export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: 'active' | 'inactive' | 'error';
  lastTriggered?: string;
}

export interface Run {
  id: string;
  taskId: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  startedAt: string;
  completedAt?: string;
  logs?: string[];
}

export interface Membership {
  userId: string;
  projectId: string;
  role: UserRole;
  user: User;
}

export interface Secret {
  id: string;
  key: string;
  createdAt: string;
  updatedAt: string;
}

export interface Repo {
  id: string;
  name: string;
  fullName: string;
  url: string;
  defaultBranch: string;
}

export interface ApiToken {
  id: string;
  name: string;
  lastUsed?: string;
  createdAt: string;
  expiresAt?: string;
}
