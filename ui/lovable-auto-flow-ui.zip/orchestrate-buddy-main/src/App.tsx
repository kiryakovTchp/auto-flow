import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProjectProvider } from "@/contexts/ProjectContext";

// Layouts
import { ProjectLayout } from "@/components/layout/ProjectLayout";

// Auth Pages
import { LoginPage } from "@/pages/auth/LoginPage";

// Global Pages
import { ProjectsPage } from "@/pages/ProjectsPage";
import NotFound from "@/pages/NotFound";

// Project Pages
import { OverviewPage } from "@/pages/project/OverviewPage";
import { TasksPage } from "@/pages/project/TasksPage";
import { TaskDetailPage } from "@/pages/project/TaskDetailPage";
import { IntegrationsPage } from "@/pages/project/IntegrationsPage";
import { WebhooksPage } from "@/pages/project/WebhooksPage";
import { RunsPage } from "@/pages/project/RunsPage";
import { SettingsPage } from "@/pages/project/SettingsPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <ProjectProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Auth Routes */}
              <Route path="/login" element={<LoginPage />} />
              
              {/* Redirect root to projects */}
              <Route path="/" element={<Navigate to="/projects" replace />} />
              
              {/* Global Routes */}
              <Route path="/projects" element={<ProjectsPage />} />
              
              {/* Project Routes */}
              <Route path="/project" element={<ProjectLayout />}>
                <Route index element={<Navigate to="overview" replace />} />
                <Route path="overview" element={<OverviewPage />} />
                <Route path="tasks" element={<TasksPage />} />
                <Route path="tasks/:taskId" element={<TaskDetailPage />} />
                <Route path="integrations" element={<IntegrationsPage />} />
                <Route path="webhooks" element={<WebhooksPage />} />
                <Route path="runs" element={<RunsPage />} />
                <Route path="settings" element={<SettingsPage />} />
              </Route>
              
              {/* Catch-all */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </ProjectProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
