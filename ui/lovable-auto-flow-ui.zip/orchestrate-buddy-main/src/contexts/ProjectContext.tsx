import { createContext, useContext, useState, ReactNode } from 'react';
import { Project } from '@/types';

interface ProjectContextType {
  currentProject: Project | null;
  projects: Project[];
  setCurrentProject: (project: Project | null) => void;
  setProjects: (projects: Project[]) => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

// Mock projects for demo
const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Platform Core',
    description: 'Main platform development',
    createdAt: '2024-01-15',
    integrations: { asana: true, github: true, opencode: true },
    memberCount: 8,
  },
  {
    id: '2',
    name: 'Mobile App',
    description: 'iOS and Android application',
    createdAt: '2024-02-01',
    integrations: { asana: true, github: true, opencode: false },
    memberCount: 5,
  },
  {
    id: '3',
    name: 'API Gateway',
    description: 'API management and gateway',
    createdAt: '2024-02-20',
    integrations: { asana: false, github: true, opencode: true },
    memberCount: 3,
  },
];

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [currentProject, setCurrentProject] = useState<Project | null>(mockProjects[0]);
  const [projects, setProjects] = useState<Project[]>(mockProjects);

  return (
    <ProjectContext.Provider
      value={{
        currentProject,
        projects,
        setCurrentProject,
        setProjects,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
}
